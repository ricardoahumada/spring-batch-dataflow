package es.netmind.demosink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
