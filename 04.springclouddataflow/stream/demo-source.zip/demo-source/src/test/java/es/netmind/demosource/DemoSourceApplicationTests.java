package es.netmind.demosource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
