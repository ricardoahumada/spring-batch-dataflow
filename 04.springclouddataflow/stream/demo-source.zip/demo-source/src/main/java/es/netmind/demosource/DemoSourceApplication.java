package es.netmind.demosource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSourceApplication.class, args);
	}

}
