package es.netmind.demoprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
