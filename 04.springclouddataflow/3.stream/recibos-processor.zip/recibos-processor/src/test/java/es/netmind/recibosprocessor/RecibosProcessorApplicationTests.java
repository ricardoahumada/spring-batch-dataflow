package es.netmind.recibosprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecibosProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
