package es.netmind.recibosprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecibosProcessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecibosProcessorApplication.class, args);
	}

}
