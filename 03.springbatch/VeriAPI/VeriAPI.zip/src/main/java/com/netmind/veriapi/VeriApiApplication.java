package com.netmind.veriapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeriApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(VeriApiApplication.class, args);
    }

}
