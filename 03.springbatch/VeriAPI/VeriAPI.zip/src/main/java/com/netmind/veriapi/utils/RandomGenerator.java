package com.netmind.veriapi.utils;

public class RandomGenerator {
    public static final boolean randomBoolean() {
        return Math.random() < 0.6;
    }
}
