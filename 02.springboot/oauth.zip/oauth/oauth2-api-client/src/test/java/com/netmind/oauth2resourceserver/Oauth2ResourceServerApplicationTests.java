package com.netmind.oauth2resourceserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2ResourceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
