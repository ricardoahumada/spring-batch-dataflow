package com.netmind.productsservice.model;

public enum ERole {
    USER,
    ADMIN
}
