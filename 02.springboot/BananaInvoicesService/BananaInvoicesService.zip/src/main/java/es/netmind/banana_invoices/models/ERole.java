package es.netmind.banana_invoices.models;

public enum ERole {
    USER,
    ADMIN
}
