package es.netmind.banana_invoices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BananaInvoicesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
